The code of C25519 has been written by Daniel Beers <dlbeer@gmail.com>
and dedicated to the public domain; refer to the file headers.

C25519 has been obtained via <https://www.dlbeer.co.nz/oss/c25519.html>.


The code of TweetNaCl has been written by:

* Daniel J. Bernstein
* Bernard von Gastel
* Wesley Janssen
* Tanja Lange
* Peter Schwabe
* Sjaak Smetsers

TweetNaCl has been dedicated to the public domain;
refer to <https://tweetnacl.cr.yp.to/>
("TweetNaCl is a self-contained public-domain C library, [...]")
and Daniel J. Bernstein et al., TweetNaCl: a crypto library in
100 tweets, LATINCRYPT 2014, pp. 64-83, (also available from
<https://tweetnacl.cr.yp.to/tweetnacl-20140917.pdf>), p. 3:
"We have placed TweetNaCl into the public domain, and we encourage
applications to make use of it".

TweetNaCl has been obtained via <https://tweetnacl.cr.yp.to/>.

